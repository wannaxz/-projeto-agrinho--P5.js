let lixo = [];
let homemX = 50;
let homemY = 300;

function setup() {
  createCanvas(600, 400);
  // Cria várias peças de lixo
  for (let i = 0; i < 20; i++) {
    lixo.push({
      x: random(width),
      y: random(height - 50, height - 10),
      tipo: random(['garrafa', 'sacola'])
    });
  }
}

function draw() {
  background(200, 220, 255); // Cor do rio
  drawRio();
  drawLixo();
  drawHomem();
  // Opcional: adicionar peixes e outros detalhes
}

function drawRio() {
  fill(0, 100, 200);
  rect(0, height - 50, width, 50);
}

function drawLixo() {
  for (let item of lixo) {
    if (item.tipo === 'garrafa') {
      fill(0, 255, 0);
      rect(item.x, item.y, 10, 20);
    } else if (item.tipo === 'sacola') {
      fill(255, 0, 0);
      rect(item.x, item.y, 15, 10);
    }
    // Movimento do lixo
    item.x += random(-1, 1);
    if (item.x < 0) item.x = width;
    if (item.x > width) item.x = 0;
  }
}

function drawHomem() {
  fill(255, 200, 150);
  ellipse(homemX, homemY - 20, 20, 20); // cabeça
  rect(homemX - 5, homemY - 10, 10, 20); // corpo
  // braços
  line(homemX - 5, homemY - 5, homemX - 15, homemY);
  line(homemX + 5, homemY - 5, homemX + 15, homemY);
  // pernas
  line(homemX - 5, homemY + 10, homemX - 10, homemY + 20);
  line(homemX + 5, homemY + 10, homemX + 10, homemY + 20);
}

function keyPressed() {
  if (key === 'LEFT') {
    homemX -= 5;
  } else if (key === 'RIGHT') {
    homemX += 5;
  }
}